import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import java.util.HashMap;

import backtype.storm.task.TopologyContext;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.*;

/**
 * a bolt that finds the top n words.
 */
public class TopNFinderBolt extends BaseBasicBolt {
  private HashMap<String, Integer> currentTopWords = new HashMap<String, Integer>();
  private int N;

  private long intervalToReport = 20;
  private long lastReportTime = System.currentTimeMillis();

  public TopNFinderBolt(int N) {
    this.N = N;
  }

    public void prepare(Map stormConf, TopologyContext context){
        currentTopWords = new HashMap<String, Integer>();
    }
    
  @Override
  public void execute(Tuple tuple, BasicOutputCollector collector) {
      
      String s = tuple.getString(0);
      Integer i = tuple.getInteger(1);
      
      Integer val = currentTopWords.get(s);
      if(val == null){
          currentTopWords.put(s,i);
      }
      else{
          currentTopWords.put(s,i + val);
      }

    //reports the top N words periodically
    if (System.currentTimeMillis() - lastReportTime >= intervalToReport) {
      collector.emit(new Values(printMap()));
      lastReportTime = System.currentTimeMillis();
    }
  }

  @Override
  public void declareOutputFields(OutputFieldsDeclarer declarer) {

     declarer.declare(new Fields("top-N"));

  }

  public String printMap() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("top-words = [ ");
      
    Vector<Entry<String, Integer>> vector = new Vector<Entry<String, Integer>>(currentTopWords.entrySet());
      
    
    Collections.sort(vector, new Comparator<Entry<String, Integer>>(){
          
          public int compare(Entry<String, Integer> number1, Entry<String, Integer> number2){
              return number1.getValue().compareTo(number2.getValue());
          }
        
    });

    int left = Math.max(vector.size() - N, 0);
        for(int i = left ; i < vector.size(); i++){
            stringBuilder.append("(" + vector.get(i).getKey() + " , " + vector.get(i).getValue().toString() + ") , ");
        }
      
    int lastCommaIndex = stringBuilder.lastIndexOf(",");
    stringBuilder.deleteCharAt(lastCommaIndex + 1);
    stringBuilder.deleteCharAt(lastCommaIndex);
    stringBuilder.append("]");
    return stringBuilder.toString();

  }
}
