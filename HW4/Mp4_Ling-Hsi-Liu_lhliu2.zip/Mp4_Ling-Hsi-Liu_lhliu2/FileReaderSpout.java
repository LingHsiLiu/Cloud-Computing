
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.IRichSpout;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;


public class FileReaderSpout implements IRichSpout {
    private SpoutOutputCollector collector;
    private TopologyContext context;

    private FileReader filereader;
    private boolean readDone = false;
    
    @Override
    public void open(Map config, TopologyContext context, SpoutOutputCollector collector){

        //  Task: initialize the file reader
        
        String file = config.get("input").toString();
        try {
            filereader = new FileReader(file);
        } 
        catch (IOException e){
            e.printStackTrace();
        }

        this.context = context;
        this.collector = collector;
    }

    @Override
    public void nextTuple(){
/*  ----------------------TODO-----------------------
Task:
    1. read the next line and emit a tuple for it
    2. don't forget to sleep when the file is entirely read to prevent a busy-loop
    ------------------------------------------------- */
		
		BufferedReader reader = new BufferedReader(filereader);
        String line;
		
        try {
            while ((line = reader.readLine()) != null){
                line = line.trim();
                if(line.length() > 0){
                    collector.emit(new Values(line));
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally{  
            readDone = true;
        }
        
        if(readDone){
            try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer){
        declarer.declare(new Fields("word"));
    }

    @Override
    public void close() {
        
// Task: close the file
        try {
			filereader.close();
		} 
        catch (IOException e) {
			e.printStackTrace();
		}
    }

    @Override
    public void activate() {
    }

    @Override
    public void deactivate() {
    }

    @Override
    public void ack(Object msgId) {
    }

    @Override
    public void fail(Object msgId) {
    }

    @Override
    public Map<String, Object> getComponentConfiguration() {
        return null;
    }
}
